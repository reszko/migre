# Mig.re - encurtador de url simpático
 Encurtador de URL feito com CodeIgniter 4
 Veja a explicação do código neste link: https://mig.re/Ev
