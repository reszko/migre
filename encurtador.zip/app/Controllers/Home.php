<?php

namespace App\Controllers;

use App\Models\LinkModel;
use Hashids\Hashids;

class Home extends BaseController
{
	public function index()
	{
		return view('home');
	}
}
