<?xml version="1.0" encoding="UTF-8"?>

-<urlset xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

    <!-- created with Free Online Sitemap Generator www.xml-sitemaps.com -->



    -<url>

        <loc>https://mig.re/</loc>

        <lastmod>2021-03-15T20:31:24+00:00</lastmod>

        <priority>1.00</priority>

    </url>


    -<url>

        <loc>https://mig.re/login</loc>

        <lastmod>2021-03-15T20:31:24+00:00</lastmod>

        <priority>0.80</priority>

    </url>


    -<url>

        <loc>https://mig.re/user/esqueciSenha</loc>

        <lastmod>2021-03-15T20:31:24+00:00</lastmod>

        <priority>0.64</priority>

    </url>

</urlset>