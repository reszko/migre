<h4>Prezado(a) usuário(a)</h4>
<p>Como solicitado, abaixo segue a nova senha gerada pelo sistema:</p>
<p><strong><?php echo $senha ?></strong></p>
<p>Você deverá utilizar a nova senha gerada para logar no sistema novamente.</p>
<p>Após logar-se, você poderá alterar sua senha novamente.</p>
<hr>
<small>Esta é uma mensagem automática. Não é preciso respondê-la.</small>
<small>Enviado por: <?php echo anchor('https://mig.re', 'mig.re - encurtador de URL simpático') ?></small>